import React, { useState, useRef, useEffect } from 'react';
import { Send, Bot, User, Heart, Brain, Users, Baby, Flower, Stethoscope, Eye, MessageCircle, Sparkles, Wind, Bone, Smile } from 'lucide-react';
import { ChatbotLogic } from '../utils/chatbotLogic';
import TypingIndicator from './TypingIndicator';

interface Message {
  id: string;
  text: string;
  isBot: boolean;
  timestamp: Date;
}

const MedicalChatbot: React.FC = () => {
  const [messages, setMessages] = useState<Message[]>([]);
  const [inputValue, setInputValue] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const [chatbot] = useState(new ChatbotLogic());
  const [showWelcome, setShowWelcome] = useState(true);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages, isTyping]);

  const specialtyCards = [
    { name: 'ألم في الصدر', icon: <Heart className="w-6 h-6 text-red-500" />, color: 'from-red-50 to-red-100 border-red-200' },
    { name: 'صداع شديد', icon: <Brain className="w-6 h-6 text-purple-500" />, color: 'from-purple-50 to-purple-100 border-purple-200' },
    { name: 'حكة في الجلد', icon: <Flower className="w-6 h-6 text-pink-500" />, color: 'from-pink-50 to-pink-100 border-pink-200' },
    { name: 'عندي برد', icon: <Wind className="w-6 h-6 text-blue-500" />, color: 'from-blue-50 to-blue-100 border-blue-200' },
    { name: 'ألم في البطن', icon: <Stethoscope className="w-6 h-6 text-green-500" />, color: 'from-green-50 to-green-100 border-green-200' },
    { name: 'تأخر الدورة الشهرية', icon: <Users className="w-6 h-6 text-rose-500" />, color: 'from-rose-50 to-rose-100 border-rose-200' },
    { name: 'حمى عند الطفل', icon: <Baby className="w-6 h-6 text-amber-500" />, color: 'from-amber-50 to-amber-100 border-amber-200' },
    { name: 'ألم في الظهر', icon: <Bone className="w-6 h-6 text-orange-500" />, color: 'from-orange-50 to-orange-100 border-orange-200' },
    { name: 'وجع أسنان', icon: <Smile className="w-6 h-6 text-cyan-500" />, color: 'from-cyan-50 to-cyan-100 border-cyan-200' }
  ];

  const handleSymptomClick = (symptom: string) => {
    setShowWelcome(false);
    setInputValue(symptom);
    handleSendMessage(symptom);
  };

  const handleSendMessage = async (customMessage?: string) => {
    const messageText = customMessage || inputValue.trim();
    if (!messageText) return;

    const userMessage: Message = {
      id: Date.now().toString(),
      text: messageText,
      isBot: false,
      timestamp: new Date()
    };

    setMessages(prev => [...prev, userMessage]);
    setInputValue('');
    setIsTyping(true);
    setShowWelcome(false);

    // Simulate AI processing delay
    setTimeout(() => {
      const botResponse = chatbot.processMessage(messageText);
      
      const botMessage: Message = {
        id: (Date.now() + 1).toString(),
        text: botResponse.response,
        isBot: true,
        timestamp: new Date()
      };

      setMessages(prev => [...prev, botMessage]);
      setIsTyping(false);

      // If booking is completed, show success animation
      if (botResponse.isComplete) {
        setTimeout(() => {
          // Reset chatbot for new session
          chatbot.reset();
          setShowWelcome(true);
          setMessages([]);
        }, 5000);
      }
    }, 1500 + Math.random() * 1000);
  };

  const handleInputKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  };

  const formatMessageText = (text: string) => {
    return text.split('\n').map((line, index) => (
      <span key={index}>
        {line}
        {index < text.split('\n').length - 1 && <br />}
      </span>
    ));
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-400 via-purple-500 to-violet-600 p-4">
      <div className="max-w-4xl mx-auto h-screen flex flex-col">
        
        {/* Welcome Screen */}
        {showWelcome && (
          <div className="flex-1 flex flex-col items-center justify-center text-white text-center px-6">
            {/* Logo */}
            <div className="bg-white/20 backdrop-blur-sm p-6 rounded-full mb-6 shadow-2xl">
              <Stethoscope className="w-16 h-16 text-white" />
            </div>
            
            {/* Title */}
            <h1 className="text-4xl font-bold mb-3">المساعد الطبي الذكي</h1>
            <p className="text-purple-100 text-lg mb-8 max-w-md">
              أخبرني عن الأعراض التي تعاني منها وسأساعدك في العثور على الطبيب المناسب
            </p>
            
            {/* Quick Symptoms */}
            <div className="w-full max-w-4xl mb-8">
              <h3 className="text-xl font-semibold mb-4 text-purple-100">أمثلة على الأعراض:</h3>
              <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-3 gap-3">
                {specialtyCards.map((card, index) => (
                  <button
                    key={index}
                    onClick={() => handleSymptomClick(card.name)}
                    className={`bg-gradient-to-r ${card.color} p-4 rounded-xl border-2 hover:scale-105 transform transition-all duration-200 shadow-lg hover:shadow-xl`}
                  >
                    <div className="flex flex-col items-center gap-2">
                      {card.icon}
                      <span className="text-sm font-bold text-gray-800 text-center leading-tight">{card.name}</span>
                    </div>
                  </button>
                ))}
              </div>
            </div>

            {/* Additional Info */}
            <div className="bg-white/10 backdrop-blur-sm rounded-2xl p-6 max-w-2xl">
              <h4 className="text-lg font-bold mb-3 text-purple-900">يمكنك أيضاً كتابة أعراض مثل:</h4>
              <div className="grid grid-cols-2 gap-2 text-sm">
                <div className="text-purple-900 font-bold">• برد وزكام</div>
                <div className="text-purple-900 font-bold">• إفرازات مهبلية</div>
                <div className="text-purple-900 font-bold">• الطفل بيعيط كتير</div>
                <div className="text-purple-900 font-bold">• حرقة في المعدة</div>
                <div className="text-purple-900 font-bold">• تنميل في اليد</div>
                <div className="text-purple-900 font-bold">• حبوب في الوجه</div>
                <div className="text-purple-900 font-bold">• ألم في الركبة</div>
                <div className="text-purple-900 font-bold">• تسوس الأسنان</div>
              </div>
            </div>
          </div>
        )}

        {/* Chat Interface */}
        {!showWelcome && (
          <>
            {/* Header */}
            <div className="bg-white/10 backdrop-blur-md rounded-t-2xl p-4 border-b border-white/20">
              <div className="flex items-center gap-3">
                <div className="bg-white/20 p-2 rounded-full">
                  <Bot className="w-6 h-6 text-white" />
                </div>
                <div>
                  <h2 className="text-white font-semibold">المساعد الطبي</h2>
                  <p className="text-purple-100 text-sm">متصل الآن</p>
                </div>
                <div className="ml-auto">
                  <Sparkles className="w-5 h-5 text-yellow-300 animate-pulse" />
                </div>
              </div>
            </div>

            {/* Messages */}
            <div className="flex-1 bg-white/5 backdrop-blur-sm overflow-y-auto p-4 space-y-4">
              {messages.map((message) => (
                <div
                  key={message.id}
                  className={`flex items-start gap-3 ${
                    message.isBot ? 'justify-start' : 'justify-end'
                  }`}
                >
                  {message.isBot && (
                    <div className="bg-white/20 p-2 rounded-full flex-shrink-0">
                      <Bot className="w-4 h-4 text-white" />
                    </div>
                  )}
                  
                  <div
                    className={`max-w-xs md:max-w-md rounded-2xl px-4 py-3 shadow-lg ${
                      message.isBot
                        ? 'bg-white/90 backdrop-blur-sm text-gray-800 text-right'
                        : 'bg-gradient-to-r from-purple-600 to-violet-700 text-white text-right'
                    }`}
                    style={{ direction: 'rtl' }}
                  >
                    <div className={`text-sm ${message.isBot ? 'text-gray-800' : 'text-white'}`}>
                      {formatMessageText(message.text)}
                    </div>
                    <div className={`text-xs mt-2 ${
                      message.isBot ? 'text-gray-500' : 'text-purple-200'
                    }`}>
                      {message.timestamp.toLocaleTimeString('ar-EG', { 
                        hour: '2-digit', 
                        minute: '2-digit' 
                      })}
                    </div>
                  </div>

                  {!message.isBot && (
                    <div className="bg-white/20 p-2 rounded-full flex-shrink-0">
                      <User className="w-4 h-4 text-white" />
                    </div>
                  )}
                </div>
              ))}
              
              {isTyping && <TypingIndicator />}
              <div ref={messagesEndRef} />
            </div>
          </>
        )}

        {/* Input Area */}
        <div className="bg-white/10 backdrop-blur-md rounded-b-2xl p-4 border-t border-white/20">
          <div className="flex gap-3">
            <div className="flex-1 relative">
              <textarea
                value={inputValue}
                onChange={(e) => setInputValue(e.target.value)}
                onKeyDown={handleInputKeyPress}
                placeholder="اكتب الأعراض التي تشعر بها..."
                className="w-full p-4 bg-white/90 backdrop-blur-sm border border-white/30 rounded-2xl resize-none focus:outline-none focus:ring-2 focus:ring-white/50 focus:border-transparent text-right placeholder-gray-500"
                style={{ direction: 'rtl' }}
                rows={2}
                disabled={isTyping}
              />
            </div>
            <button
              onClick={() => handleSendMessage()}
              disabled={!inputValue.trim() || isTyping}
              className="bg-gradient-to-r from-purple-600 to-violet-700 hover:from-purple-700 hover:to-violet-800 disabled:bg-gray-400 disabled:cursor-not-allowed text-white p-4 rounded-2xl transition-all duration-200 flex-shrink-0 shadow-lg hover:shadow-xl transform hover:scale-105 disabled:transform-none"
            >
              <Send className="w-5 h-5" />
            </button>
          </div>
          
          <div className="flex justify-center mt-3">
            <p className="text-xs text-purple-100 text-center flex items-center gap-1">
              <MessageCircle className="w-3 h-3" />
              اكتب أعراضك بوضوح للحصول على أفضل توجيه طبي
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default MedicalChatbot;