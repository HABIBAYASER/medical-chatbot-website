import React from 'react';
import { Bot } from 'lucide-react';

const TypingIndicator: React.FC = () => {
  return (
    <div className="flex items-start gap-3 justify-start">
      <div className="bg-white/20 p-2 rounded-full flex-shrink-0">
        <Bot className="w-4 h-4 text-white" />
      </div>
      <div className="bg-white/90 backdrop-blur-sm rounded-2xl px-4 py-3 shadow-lg">
        <div className="flex gap-1">
          <div className="w-2 h-2 bg-purple-500 rounded-full animate-bounce" />
          <div className="w-2 h-2 bg-purple-500 rounded-full animate-bounce delay-100" />
          <div className="w-2 h-2 bg-purple-500 rounded-full animate-bounce delay-200" />
        </div>
      </div>
    </div>
  );
};

export default TypingIndicator;