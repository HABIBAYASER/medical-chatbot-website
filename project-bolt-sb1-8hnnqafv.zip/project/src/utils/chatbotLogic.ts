import { DoctorsData } from '../data/doctorsData';
import { SymptomsMapping } from '../data/symptomsMapping';

interface Doctor {
  id: string;
  name: string;
  specialty: string;
  schedule: string;
  consultationPrice: number;
  callPrice?: number;
  phone: string;
  address: string;
  rating: number;
  experience: number;
}

interface ChatbotResponse {
  response: string;
  isComplete: boolean;
}

export class ChatbotLogic {
  private currentStep: string = 'symptoms';
  private specialty: string = '';
  private availableDoctors: Doctor[] = [];
  private selectedDoctor: Doctor | null = null;
  private availableAppointments: string[] = [];
  private selectedAppointment: string = '';

  processMessage(userInput: string): ChatbotResponse {
    const input = userInput.trim();

    switch (this.currentStep) {
      case 'symptoms':
        return this.handleSymptoms(input);
      case 'doctor_selection':
        return this.handleDoctorSelection(input);
      case 'appointment_selection':
        return this.handleAppointmentSelection(input);
      case 'booking_confirmation':
        return this.handleBookingConfirmation(input);
      default:
        return { response: 'يرجى وصف الأعراض التي تشعر بها:', isComplete: false };
    }
  }

  private handleSymptoms(userInput: string): ChatbotResponse {
    const inputLower = userInput.toLowerCase();
    let detectedSpecialty: string | null = null;

    // Check for symptoms in the input
    for (const [symptom, specialty] of Object.entries(SymptomsMapping)) {
      if (inputLower.includes(symptom.toLowerCase())) {
        detectedSpecialty = specialty;
        break;
      }
    }

    if (!detectedSpecialty) {
      return {
        response: `لم أتمكن من تحديد التخصص المناسب من الأعراض المذكورة.

يرجى المحاولة مرة أخرى باستخدام أعراض أوضح، مثل:
• ألم في الصدر، خفقان (أمراض القلب)
• صداع، دوخة (مخ وأعصاب)  
• حكة، طفح جلدي (جلدية)
• ألم في الأذن، التهاب الحلق (أنف وأذن وحنجرة)
• ألم في البطن، غثيان (باطنة عامة)
• تأخر الدورة الشهرية (نساء وتوليد)
• حمى عند الطفل (أطفال)`,
        isComplete: false
      };
    }

    // Get available doctors for the specialty
    this.availableDoctors = DoctorsData.filter(doctor => doctor.specialty === detectedSpecialty);
    this.specialty = detectedSpecialty;
    this.currentStep = 'doctor_selection';

    let response = `🎯 التخصص المحدد: ${detectedSpecialty}\n\n👨‍⚕️ الأطباء المتاحون:\n\n`;

    this.availableDoctors.forEach((doctor, index) => {
      const callInfo = doctor.callPrice ? `📞 ${doctor.callPrice} جنيه` : '📞 غير متاحة';
      response += `${index + 1}. د. ${doctor.name}\n`;
      response += `   ⭐ ${doctor.rating}/5 (${doctor.experience} سنوات خبرة)\n`;
      response += `   📍 ${doctor.address}\n`;
      response += `   💰 كشف: ${doctor.consultationPrice} جنيه | ${callInfo}\n`;
      response += `   📅 ${doctor.schedule}\n\n`;
    });

    response += '🔢 اختر رقم الطبيب من القائمة أعلاه:';
    return { response, isComplete: false };
  }

  private handleDoctorSelection(userInput: string): ChatbotResponse {
    const doctorIndex = parseInt(userInput.trim()) - 1;

    if (isNaN(doctorIndex) || doctorIndex < 0 || doctorIndex >= this.availableDoctors.length) {
      return {
        response: `❌ يرجى اختيار رقم صحيح من 1 إلى ${this.availableDoctors.length}`,
        isComplete: false
      };
    }

    this.selectedDoctor = this.availableDoctors[doctorIndex];
    this.currentStep = 'appointment_selection';
    this.availableAppointments = this.generateAppointments();

    let response = `✅ تم اختيار: د. ${this.selectedDoctor.name}\n\n📅 المواعيد المتاحة:\n\n`;

    this.availableAppointments.forEach((appointment, index) => {
      response += `${index + 1}. ${appointment}\n`;
    });

    response += '\n🔢 اختر رقم الموعد المناسب:';
    return { response, isComplete: false };
  }

  private handleAppointmentSelection(userInput: string): ChatbotResponse {
    const appointmentIndex = parseInt(userInput.trim()) - 1;

    if (isNaN(appointmentIndex) || appointmentIndex < 0 || appointmentIndex >= this.availableAppointments.length) {
      return {
        response: `❌ يرجى اختيار رقم صحيح من 1 إلى ${this.availableAppointments.length}`,
        isComplete: false
      };
    }

    this.selectedAppointment = this.availableAppointments[appointmentIndex];
    this.currentStep = 'booking_confirmation';

    const response = `📋 ملخص الحجز:

👨‍⚕️ الطبيب: د. ${this.selectedDoctor!.name}
🏥 التخصص: ${this.selectedDoctor!.specialty}
📅 الموعد: ${this.selectedAppointment}
📍 العنوان: ${this.selectedDoctor!.address}
💰 تكلفة الكشف: ${this.selectedDoctor!.consultationPrice} جنيه
⭐ التقييم: ${this.selectedDoctor!.rating}/5
📞 رقم العيادة: ${this.selectedDoctor!.phone}

✅ تأكيد الحجز؟ (نعم/لا)`;

    return { response, isComplete: false };
  }

  private handleBookingConfirmation(userInput: string): ChatbotResponse {
    const input = userInput.trim().toLowerCase();

    if (['نعم', 'yes', 'موافق', 'تأكيد', 'احجز'].includes(input)) {
      const bookingId = `BK${Date.now().toString().slice(-6)}`;
      
      const response = `🎉 تم تأكيد حجزك بنجاح!

🎫 رقم الحجز: ${bookingId}
👨‍⚕️ الطبيب: د. ${this.selectedDoctor!.name}
📅 الموعد: ${this.selectedAppointment}
📍 العنوان: ${this.selectedDoctor!.address}
💰 المبلغ المطلوب: ${this.selectedDoctor!.consultationPrice} جنيه
📞 للاستفسار: ${this.selectedDoctor!.phone}

📝 تعليمات مهمة:
• احضر قبل الموعد بـ 15 دقيقة
• أحضر الهوية الشخصية
• أحضر أي تحاليل أو أشعة سابقة

شكراً لثقتك في خدمتنا! 🙏
نتمنى لك الشفاء العاجل ❤️`;

      return { response, isComplete: true };
    } else if (['لا', 'no', 'إلغاء', 'الغاء'].includes(input)) {
      return { 
        response: '❌ تم إلغاء الحجز.\n\nيمكنك البدء من جديد بوصف الأعراض التي تشعر بها.',
        isComplete: true 
      };
    } else {
      return {
        response: '🤔 يرجى الإجابة بـ "نعم" لتأكيد الحجز أو "لا" لإلغائه',
        isComplete: false
      };
    }
  }

  private generateAppointments(): string[] {
    const appointments: string[] = [];
    const today = new Date();
    const days = ['الأحد', 'الإثنين', 'الثلاثاء', 'الأربعاء', 'الخميس', 'الجمعة', 'السبت'];
    const timeSlots = ['10:00 صباحاً', '12:00 ظهراً', '2:00 مساءً', '4:00 مساءً', '6:00 مساءً', '8:00 مساءً'];

    for (let i = 1; i <= 7; i++) {
      const date = new Date(today);
      date.setDate(today.getDate() + i);
      
      // Skip Fridays for most doctors
      if (date.getDay() === 5 && Math.random() > 0.3) continue;
      
      const dayName = days[date.getDay()];
      const dateStr = date.toLocaleDateString('ar-EG');
      const availableSlots = timeSlots.filter(() => Math.random() > 0.4);
      
      availableSlots.forEach(slot => {
        appointments.push(`${dayName} ${dateStr} - ${slot}`);
      });
    }

    return appointments.slice(0, 8); // Return max 8 appointments
  }

  reset(): void {
    this.currentStep = 'symptoms';
    this.specialty = '';
    this.availableDoctors = [];
    this.selectedDoctor = null;
    this.availableAppointments = [];
    this.selectedAppointment = '';
  }
}