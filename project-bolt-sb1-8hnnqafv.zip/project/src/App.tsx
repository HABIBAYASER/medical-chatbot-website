import React from 'react';
import MedicalChatbot from './components/MedicalChatbot';

function App() {
  return (
    <div className="min-h-screen">
      <MedicalChatbot />
    </div>
  );
}

export default App;